<!-- <script src="./laboratory/lib/jquery/dist/jquery.min.js"></script> -->
<script src="./laboratory/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="./laboratory/lib/jquery-datetimepicker/build/jquery.datetimepicker.full.min.js"></script>
<script src="./laboratory/lib/jquery-toast-plugin/dist/jquery.toast.min.js"></script>
<script src="./laboratory/lib/select2/dist/js/select2.full.min.js"></script>
<script src="./laboratory/lib/sweetalert2/dist/sweetalert2.all.min.js"></script>
<script src="./laboratory/lib/datatables/js/dataTables.dataTables.min.js"></script>